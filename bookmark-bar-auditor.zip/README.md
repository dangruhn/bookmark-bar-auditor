# bookmark-bar-auditor
Walk through the Firefox bookmark bar bookmarks refreshing the icons and checking to see which are no longer valid.
